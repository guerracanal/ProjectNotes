# ProjectNotes — paquete standalone

Generado por `npm run build:standalone`. **No editar a mano**: cada build
borra y rehace esta carpeta.

## Arrancar

```bash
node server.js
```

No necesita `npm install`: las dependencias que el servidor usa ya están en
`node_modules/`. Sí necesita Node 20 o superior.

## Qué usa y de dónde

Al arrancar imprime lo que ha resuelto. Por defecto:

| Qué | Dónde | Variable para cambiarlo |
| --- | --- | --- |
| Proyectos | `./projects_data`, y si no existe, `../projects_data` | `PROJECTS_DIR` |
| Índice del asistente | `.projectnotes/` junto a los proyectos | `PROJECTNOTES_INDEX_DIR` |
| Claves y ajustes | `.env.local` y `.env` de esta carpeta, luego los de la carpeta padre | — |
| Python (transcribir/resumir) | `venv/` de esta carpeta o de la padre | `PYTHON_BIN` |
| Puerto | 3000 | `PORT` |

Mirar en la carpeta padre es deliberado: mientras el paquete viva dentro del
repo, comparte datos, índice y claves con `npm run dev` en vez de duplicarlos.

## Llevárselo a otra máquina

Copiar la carpeta entera. Allí hará falta:

1. Un `projects_data/` dentro (o `PROJECTS_DIR` apuntando a él).
2. Un `.env.local` con las claves, si se quiere el asistente. Sin clave el
   asistente sigue funcionando con búsqueda léxica local.
3. Un `venv` con `pip install -r requirements.txt`, solo si se va a
   transcribir o resumir desde esa máquina.
