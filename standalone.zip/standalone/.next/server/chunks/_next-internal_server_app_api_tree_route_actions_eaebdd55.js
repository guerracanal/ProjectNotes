module.exports=[27356,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_tree_route_actions_eaebdd55.js.map