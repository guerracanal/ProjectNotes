module.exports=[82191,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app__well-known_assetlinks_json_route_actions_885ca032.js.map