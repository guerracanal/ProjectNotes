module.exports=[13101,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_projects_upload_route_actions_978b6177.js.map