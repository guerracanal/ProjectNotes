module.exports=[30949,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_projects_%5B%5B___path%5D%5D_route_actions_5b653806.js.map