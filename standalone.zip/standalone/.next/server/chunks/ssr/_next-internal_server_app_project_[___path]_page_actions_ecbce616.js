module.exports=[25987,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_project_%5B___path%5D_page_actions_ecbce616.js.map