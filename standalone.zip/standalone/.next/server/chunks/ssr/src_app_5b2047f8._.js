module.exports=[10585,a=>{a.v("/_next/static/media/favicon.200f642b.ico")},68611,a=>{"use strict";let b={src:a.i(10585).default,width:32,height:32};a.s(["default",0,b])}];

//# sourceMappingURL=src_app_5b2047f8._.js.map