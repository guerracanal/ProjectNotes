1:"$Sreact.fragment"
2:I[71987,["/_next/static/chunks/275b65a5bfb5e471.js","/_next/static/chunks/a7ebdd24431cf8e5.js","/_next/static/chunks/29db750cbe9b34a0.js","/_next/static/chunks/a0bd5aea1d3ffb51.js"],"default"]
3:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/c81db6e24f0cfdeb.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"IVGfQ3qaK3H4RFR2qOtgK","rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/_next/static/chunks/a0bd5aea1d3ffb51.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
