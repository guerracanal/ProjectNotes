1:"$Sreact.fragment"
2:I[71987,["/_next/static/chunks/26b644f29871256a.js","/_next/static/chunks/159448e20f77ca8d.js","/_next/static/chunks/f969cb2cb6d13be9.js","/_next/static/chunks/a0bd5aea1d3ffb51.js"],"default"]
3:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/c81db6e24f0cfdeb.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"fYuWS2Xs6aAMepg0Kv_4M","rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/_next/static/chunks/a0bd5aea1d3ffb51.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
