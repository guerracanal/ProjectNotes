1:"$Sreact.fragment"
2:I[71987,["/_next/static/chunks/26b644f29871256a.js","/_next/static/chunks/b68a6292e3d739a9.js","/_next/static/chunks/f98428bb2e88c0f9.js","/_next/static/chunks/06c2f07878df5074.js"],"default"]
3:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/c81db6e24f0cfdeb.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"_H1Y-3wLQTSyggje7MWcU","rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/_next/static/chunks/06c2f07878df5074.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
