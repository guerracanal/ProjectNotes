var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/.well-known/assetlinks.json/route.js")
R.c("server/chunks/[root-of-the-server]__04a624f7._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app__well-known_assetlinks_json_route_actions_885ca032.js")
R.m(1856)
module.exports=R.m(1856).exports
