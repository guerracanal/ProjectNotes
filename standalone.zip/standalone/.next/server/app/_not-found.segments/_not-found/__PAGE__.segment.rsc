1:"$Sreact.fragment"
2:I[22016,["/_next/static/chunks/26b644f29871256a.js","/_next/static/chunks/a7ebdd24431cf8e5.js","/_next/static/chunks/f969cb2cb6d13be9.js"],""]
3:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/c81db6e24f0cfdeb.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"KdGT2DiuzYzZuZ6N-tI-L","rsc":["$","$1","c",{"children":[["$","div",null,{"className":"card card-pad","style":{"textAlign":"center","padding":"var(--sp-12)"},"children":[["$","h1",null,{"className":"page-title","style":{"marginBottom":"var(--sp-2)"},"children":"No encontrado"}],["$","p",null,{"className":"page-subtitle","style":{"marginBottom":"var(--sp-5)"},"children":["La carpeta o página que buscas no existe dentro de ",["$","code",null,{"children":"projects_data"}],"."]}],["$","$L2",null,{"href":"/","className":"btn btn-primary","children":"Volver al panel"}]]}],null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
