var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/tasks/all/route.js")
R.c("server/chunks/[root-of-the-server]__74b70b26._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_tasks_all_route_actions_c32f91c5.js")
R.m(84794)
module.exports=R.m(84794).exports
