var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/tree/route.js")
R.c("server/chunks/[root-of-the-server]__12e29b06._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_tree_route_actions_eaebdd55.js")
R.m(65139)
module.exports=R.m(65139).exports
