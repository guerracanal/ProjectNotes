var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/models/route.js")
R.c("server/chunks/[root-of-the-server]__23b7c6a8._.js")
R.c("server/chunks/node_modules_d4ef3a22._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_models_route_actions_b6abdc83.js")
R.m(37828)
module.exports=R.m(37828).exports
