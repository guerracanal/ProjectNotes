var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/sync/gdrive/route.js")
R.c("server/chunks/[root-of-the-server]__5d730643._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__6b56f9d3._.js")
R.c("server/chunks/_next-internal_server_app_api_sync_gdrive_route_actions_acad4ff7.js")
R.m(82760)
module.exports=R.m(82760).exports
