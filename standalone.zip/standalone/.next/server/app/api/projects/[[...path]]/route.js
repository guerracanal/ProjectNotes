var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/projects/[[...path]]/route.js")
R.c("server/chunks/src_lib_knowledge_41b69984._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__5cef4528._.js")
R.c("server/chunks/_next-internal_server_app_api_projects_[[___path]]_route_actions_5b653806.js")
R.m(34566)
module.exports=R.m(34566).exports
