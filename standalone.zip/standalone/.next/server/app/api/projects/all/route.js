var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/projects/all/route.js")
R.c("server/chunks/[root-of-the-server]__1a085d62._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_projects_all_route_actions_8c89abf2.js")
R.m(71696)
module.exports=R.m(71696).exports
