var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/projects/upload/route.js")
R.c("server/chunks/[root-of-the-server]__c8238ffe._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_projects_upload_route_actions_978b6177.js")
R.m(57083)
module.exports=R.m(57083).exports
