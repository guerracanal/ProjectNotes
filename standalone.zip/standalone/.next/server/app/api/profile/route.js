var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/profile/route.js")
R.c("server/chunks/[root-of-the-server]__2a2a8645._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_profile_route_actions_0369ef5c.js")
R.m(76314)
module.exports=R.m(76314).exports
