var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/chat/route.js")
R.c("server/chunks/src_lib_knowledge_db2a6a90._.js")
R.c("server/chunks/[root-of-the-server]__981995d8._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/node_modules_d4ef3a22._.js")
R.c("server/chunks/_next-internal_server_app_api_chat_route_actions_ac0c75e3.js")
R.m(32336)
module.exports=R.m(32336).exports
