var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/knowledge/route.js")
R.c("server/chunks/src_lib_knowledge_41b69984._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__68b570b7._.js")
R.c("server/chunks/_next-internal_server_app_api_knowledge_route_actions_7443ce7e.js")
R.m(55283)
module.exports=R.m(55283).exports
