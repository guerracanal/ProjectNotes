var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/transcribe/route.js")
R.c("server/chunks/[root-of-the-server]__d9667071._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_transcribe_route_actions_4742f5c6.js")
R.m(60163)
module.exports=R.m(60163).exports
