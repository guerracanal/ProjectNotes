var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/summarize/route.js")
R.c("server/chunks/[root-of-the-server]__4f3590ff._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_summarize_route_actions_3e77989a.js")
R.m(73946)
module.exports=R.m(73946).exports
