globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/2d8a63e1eae37e0b.js",
    "static/chunks/6c30316e8232e501.js",
    "static/chunks/3daff37f20691d18.js",
    "static/chunks/67e9ba0323896ae2.js",
    "static/chunks/turbopack-30f20e16a9e90dcc.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];